#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 14:28:11 2019

@author: saurabh
"""

import pandas as pd
import numpy as np
from tpot import TPOTClassifier
from sklearn.model_selection import train_test_split



datas=str(input())
dataset=pd.read_csv(datas)
X=dataset.iloc[:,:-1].values
cols=len(dataset.columns)
Y=dataset.iloc[:,[cols-1]].values
X_train,X_test,Y_train,Y_test=train_test_split(X,Y,test_size=0.25)
print(X_train.shape)
tpot = TPOTClassifier(generations=2, population_size=2, verbosity=2)
tpot.fit(X_train, Y_train)
tpot.export('tpot_diabetes_pipeline.py')


