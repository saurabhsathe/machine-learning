import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

# NOTE: Make sure that the class is labeled 'target' in the data file
tpot_data = pd.read_csv('oppreocessed.csv', sep=',', dtype=np.float64)
x=tpot_data.iloc[:,:-1].values
mylen=len(tpot_data.columns)
y=tpot_data.iloc[:,[mylen-1]].values
cols=len(tpot_data.columns)
cols=cols-1
features = tpot_data.drop(cols, axis=1).values
xtrain,xtest,ytrain,ytest=train_test_split(x,y,test_size=0.25)
# Average CV score on the training set was:0.5669645662416868
exported_pipeline = DecisionTreeClassifier(criterion="entropy", max_depth=3, min_samples_leaf=4, min_samples_split=11)

exported_pipeline.fit(xtrain, ytrain)
results = exported_pipeline.predict(xtest)

from sklearn.metrics import classification_report
target=['less than 30 days','greater than 30 days','no']
print(classification_report(ytest, results, target_names=target))
